#include <Core/engine.h>


int main()
{
	/*Engine engine;
	bool is_engine_init = engine.initialize();

	if (!is_engine_init) return -1;

	engine.run();
	engine.close();*/

	return 0;
}